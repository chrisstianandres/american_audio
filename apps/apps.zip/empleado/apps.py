from django.apps import AppConfig


class EmpleadoConfig(AppConfig):
    name = 'apps.empleado'
