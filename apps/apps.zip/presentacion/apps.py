from django.apps import AppConfig


class PresentacionConfig(AppConfig):
    name = 'apps.presentacion'
