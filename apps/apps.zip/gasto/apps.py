from django.apps import AppConfig


class GastoConfig(AppConfig):
    name = 'apps.gasto'
