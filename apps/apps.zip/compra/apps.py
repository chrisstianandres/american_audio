from django.apps import AppConfig


class CompraConfig(AppConfig):
    name = 'apps.compra'
