from django.apps import AppConfig


class CargoConfig(AppConfig):
    name = 'apps.cargo'
