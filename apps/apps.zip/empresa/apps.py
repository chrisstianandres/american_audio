from django.apps import AppConfig


class EmpresaConfig(AppConfig):
    name = 'apps.empresa'
