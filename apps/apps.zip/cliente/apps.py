from django.apps import AppConfig


class ClienteConfig(AppConfig):
    name = 'apps.cliente'
