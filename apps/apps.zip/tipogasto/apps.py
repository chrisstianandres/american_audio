from django.apps import AppConfig


class TipogastoConfig(AppConfig):
    name = 'apps.tipogasto'
