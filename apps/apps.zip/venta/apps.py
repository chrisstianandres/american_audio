from django.apps import AppConfig


class VentaConfig(AppConfig):
    name = 'apps.venta'
