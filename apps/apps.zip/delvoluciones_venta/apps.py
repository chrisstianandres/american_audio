from django.apps import AppConfig


class DelvolucionesVentaConfig(AppConfig):
    name = 'apps.delvoluciones_venta'
