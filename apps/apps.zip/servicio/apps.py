from django.apps import AppConfig


class ServicioConfig(AppConfig):
    name = 'apps.servicio'
