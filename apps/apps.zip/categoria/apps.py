from django.apps import AppConfig


class CategoriaConfig(AppConfig):
    name = 'apps.categoria'
