from django.apps import AppConfig


class DatabasebackupsConfig(AppConfig):
    name = 'apps.DatabaseBackups'
